package com.jewishlewish.mis388;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mis388ApplicationTests {

	@Test
	void contextLoads() {
	}

}
